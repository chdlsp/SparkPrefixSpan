import org.apache.spark.{ SparkConf, SparkContext }
// $example on$
import org.apache.spark.mllib.fpm.PrefixSpan2

import org.apache.spark.mllib.fpm.PrefixSpan
// $example off$
import java.util.Arrays;
import scala.io.Source
/* file reading example */
import scala.io.Source

object PrefixSpanExample {

  def main(args: Array[String]) {
    val conf = new SparkConf().setAppName("PrefixSpanExample").setMaster("local[2]")
    val sc = new SparkContext(conf)
    
//    val line_tmp = Array(Array())
//    val i = 0
//    for(line <- Source.fromFile("/Users/sh/Downloads/SparkTest/src/seq.txt","utf-8").getLines()){
//      val t = line.toArray
//      line_tmp :+ t
//      }
//    
//    println(line_tmp) 
    // $example on$
//    val sequences = sc.parallelize(Seq(
//      Array(Array('a', 'b', 'c', 'd', 'e'),
//      Array('a', 'b', 'c', 'd','e', 'f'),
//      Array('b', 'c', 'd'),
//      Array('b', 'c', 'd','e'),
//      Array('b', 'f'),
//      Array('c', 'd', 'e')))).cache()
      
    val sequences = sc.parallelize(Seq(
      Array(Array('a', 'b', 'c', 'd', 'e')),
      Array(Array('a', 'b', 'c')),
      Array(Array('b', 'c', 'd')),
      Array(Array('b', 'c', 'e')),
      Array(Array('c', 'd', 'e')))).cache()
//    val sequences = sc.parallelize(Seq(
//      Array(Array("Bolting", "Positioning", "Tagging", "Wait", "Standing")),
//      Array(Array("Bolting", "Positioning", "Tagging")),
//      Array(Array("Positioning", "Tagging", "Wait")),
//      Array(Array("Positioning", "Tagging", "Standing")),
//      Array(Array("Tagging", "Wait", "Standing")))).cache()
////      
     
    val tempData = Array(
      Array('a', 'b', 'c', 'd', 'e'),
      Array('a', 'b', 'c'),
      Array('b', 'c', 'd'),
      Array('b', 'c', 'e'),
      Array('c', 'd', 'e'));
//    val tempData = Array(
//      Array("Bolting", "Positioning", "Tagging", "Wait", "Standing"),
//      Array("Bolting", "Positioning", "Tagging"),
//      Array("Positioning", "Tagging", "Wait"),
//      Array("Positioning", "Tagging", "Standing"),
//      Array("Tagging", "Wait", "Standing"));
    val timeStampsList = Array(   
      Array(1L, 2L, 3L, 4L, 5L),
      Array(6L, 7L, 8L),
      Array(9L, 10L, 11L),
      Array(12L, 13L, 14L),
      Array(15L, 16L, 18L));
    
    val values = Array(
      Array(1L, 2L, 3L, 4L, 5L),
      Array(6L, 7L, 8L),
      Array(9L, 10L, 11L),
      Array(12L, 13L, 14L),
      Array(15L, 16L, 18L));
    
    val prefixSpan2 = new PrefixSpan2()
      .setMinSupport(0.5)
      .setMaxPatternLength(5)

    val model = prefixSpan2.run(sequences, tempData, values);
      
      
    
//    val prefixSpan = new PrefixSpan2().setMinSupport(0.5).setMaxPatternLength(5)
//
//    val model = prefixSpan.run(sequences,null,null);
//    
    
    model.freqSequences.collect().foreach { freqSequence =>
      println(
        s"${freqSequence.sequence.map(_.mkString("[", ", ", "]")).mkString("[", ", ", "]")}," +
          s" ${freqSequence.freq}")
    }
//     $example off$
    sc.stop()
  }
}