package PrefixSpan3

class scala {
  
}